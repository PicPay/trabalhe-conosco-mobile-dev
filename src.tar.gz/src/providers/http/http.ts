import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Http,Headers,RequestOptions,Response} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/retry';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/debounceTime';


/*
  Generated class for the HttpProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class HttpProvider {  

  constructor(public http: Http) {}

  public listUsers(){
    
    let url = 'http://careers.picpay.com/tests/mobdev/users';    

    let headers = new Headers();

    headers.append('Content-Type', 'application/json;charset=utf-8');

    let options = new RequestOptions({ headers: headers });

    return this.http.get(url,options).retry(3).timeout(10000).map((res:Response) => res.json());

  } 

  public transferencia(card_number,cvv,value,expiry_date,destination_user_id){

    let aux = {'card_number':card_number,'cvv':cvv,'value':value,'expiry_date':expiry_date,'destination_user_id':destination_user_id};
    
    let dados : any;

    dados = JSON.stringify(aux);

    let url = 'http://careers.picpay.com/tests/mobdev/transaction';

    let headers = new Headers();

    headers.append('Content-Type', 'application/json;charset=utf-8');

    let options = new RequestOptions({ headers: headers });

    return this.http.post(url, dados, options).retry(3).timeout(10000).map((res:Response) => res.json());
    
  }

}
