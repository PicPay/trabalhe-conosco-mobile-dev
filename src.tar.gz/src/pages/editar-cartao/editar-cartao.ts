import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ToastController,ActionSheetController,LoadingController } from 'ionic-angular';

/**
 * Generated class for the EditarCartaoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-editar-cartao',
  templateUrl: 'editar-cartao.html',
})
export class EditarCartaoPage {

  idcartao : number = -1;
  validade1 : string = "";
  validade2 : string = "";
  cvv : string = "";
  numero : string = "";
  numero_old : string = "";
  flagerro : boolean = false;

  constructor(public navCtrl: NavController, public params: NavParams,public loadingCtrl: LoadingController,public toastCtrl: ToastController,public actionSheetCtrl: ActionSheetController) {
  }

  ionViewDidLoad() {
    
    try{

      this.idcartao = this.params.get('idcartao');
      this.numero = this.params.get('numero');
      this.numero_old = this.params.get('numero');
      this.cvv = this.params.get('cvv');
      this.validade2 = this.params.get('validade');

      if (this.validade2.length>0) {

        let aux = this.validade2.split('/');          

        let data = new Date(parseInt(aux[1]),parseInt(aux[0])-1,1);
        
        this.validade1 = data.toISOString()      

      }   
    
    }catch(e){

      let toast = this.toastCtrl.create({message: 'Não foi possível consultar o cartão no momento. Tente novamente.',duration:2000});

      toast.present();
      
      this.validade2 = "";
      this.numero = "";
      this.cvv = "";
      this.flagerro = true;

    }finally{

    }

  }

  excluir(){

    let actionSheet = this.actionSheetCtrl.create({title: 'Deseja excluir esse cartão ?',buttons: [{text: 'Sim',handler: () => {this.excluir_cartao();}},{text: 'Não',handler: () => {}}]});
 
    actionSheet.present();

  }

  excluir_cartao(){

    let cartoes : any = [];

    let id : number = 0;

    id = this.idcartao;

    const loader = this.loadingCtrl.create({content: "",spinner:'bubbles'});

    loader.present();

    if(localStorage.getItem('cartoes')!=null) cartoes = JSON.parse(localStorage.getItem('cartoes'));

    let cartoes_atualizados = cartoes.filter(function(value){return value.id != id});

    localStorage.setItem('cartoes',JSON.stringify(cartoes_atualizados));

    loader.dismiss();

    let toast = this.toastCtrl.create({message: 'Cartão excluído com sucesso.',duration:2000});

    toast.present();

    this.navCtrl.pop();

  }

  salvar(){

    let cartoes : any = [];

    let id : number = 0;

    id = this.idcartao;

    let num = this.numero;

    if(this.validarNumero()) return

    if(this.validade2.length == 0){

      let toast = this.toastCtrl.create({message: 'Informe a data de validade do cartão de crédito.',duration:2000});

      toast.present();

      return

    }

    if(this.validarCvv()) return    

    if(localStorage.getItem('cartoes')!=null) cartoes = JSON.parse(localStorage.getItem('cartoes'));

    if(this.numero != this.numero_old){

      let cartoes_cadastrados = cartoes.filter(function(value){return value.numero == num});
      
      if(cartoes_cadastrados.length>0){

        let toast1 = this.toastCtrl.create({message: 'Esse cartão já foi cadastrado.',duration:2000});

        toast1.present();

        return;

      }

    }

    const loader = this.loadingCtrl.create({content: "",spinner:'bubbles'});

    loader.present();       

    let cartao = cartoes.find(function(value){return value.id == id});

    cartao.numero = this.numero;
    cartao.cvv = this.cvv;
    cartao.validade = this.validade2;

    let cartoes_atualizados = cartoes.filter(function(value){return value.id != id})

    cartoes_atualizados.push(cartao);    

    localStorage.setItem('cartoes',JSON.stringify(cartoes_atualizados));

    loader.dismiss();

    let toast = this.toastCtrl.create({message: 'Cartão atualizado com sucesso.',duration:2000});

    toast.present();    

    this.navCtrl.pop();

  }

  validarCvv(){

    let regexp1 = new RegExp(/^\d+$/i);    

    if(this.cvv.length == 0){

        let toast = this.toastCtrl.create({message: 'Informe o CVV do cartão.',duration:2000});

        toast.present();       

        return true

    }  
    
    if (regexp1.test(this.cvv)) {

    }else{

        let toast = this.toastCtrl.create({message: 'Informe o CVV do cartão corretamente.',duration:2000});

        toast.present();        

        return true

    }

    return false;
  }   

  cancelar(){    

    this.navCtrl.pop();   

  }

  validarNumero(){

    let regexp1 = new RegExp(/^\d+$/i);    

    if(this.numero.length == 0){

        let toast = this.toastCtrl.create({message: 'Informe o numero do cartão.',duration:2000});

        toast.present();       

        return true

    }  
    
    if (regexp1.test(this.numero)) {

    }else{

        let toast = this.toastCtrl.create({message: 'Informe o número do cartão corretamente.',duration:2000});

        toast.present();        

        return true

    }

    return false;
  } 
  
  public customOptionsValidade: any = {

    buttons: [

      {text: 'Limpar',handler: (data) => {
        this.validade1 = '';
        this.validade2 = '';
      }},

      {

        text: 'Ok',

        handler: (data) => {         

          let dataagora = new Date();

          let event1 = new Date(data.year.value, data.month.value-1,1,0,0,0);          

          let options1 = { year: 'numeric', month: 'numeric', day: 'numeric'};

          let date = event1.toLocaleDateString('pt-BR', options1);                                                 

          dataagora.setHours(0)
          dataagora.setMinutes(0)
          dataagora.setSeconds(0)                    

          if(event1 > dataagora){

            let options2 = { year: 'numeric', month: 'numeric'};

            date = event1.toLocaleDateString('pt-BR', options2);            

            this.validade1 = event1.toISOString();

            this.validade2 = date;

          }else{

            let toast = this.toastCtrl.create({message: 'Esse cartão está vencido. Informe uma data válida.',duration:2000});

            toast.present();

          }

        }

      },

      {

        text: 'Cancelar',

        handler: (data) => {}

      }

    ]

  } 

}
