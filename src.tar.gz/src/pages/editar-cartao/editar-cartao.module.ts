import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditarCartaoPage } from './editar-cartao';

@NgModule({
  declarations: [
    EditarCartaoPage,
  ],
  imports: [
    IonicPageModule.forChild(EditarCartaoPage),
  ],
})
export class EditarCartaoPageModule {}
