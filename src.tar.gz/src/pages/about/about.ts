import { Component } from '@angular/core';
import { NavController,LoadingController } from 'ionic-angular';

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {

  tam : number = 0; 
  ultimastransferencias : any = [];
  ultimastransferencias_filtrados : any = [];
  totaltransferencia : number = 0;
  total : string = "";
  limite : number = 10;  

  constructor(public navCtrl: NavController,public loadingCtrl: LoadingController) {}

  ionViewWillEnter() {       

    let ultimas : any = [];
    let cartoes : any = [];
    let usuarios : any = [];

    this.ultimastransferencias = [];    
    this.ultimastransferencias_filtrados = [];    

    let cartao : any = null;
    let usuario : any = null;

    let idcartao : number = -1;
    let idusuario : number = -1;

    let aux : number = 0;

    let numero : number = 0;
    let img : string="";
    let nome : string = "";
    let username : string = "";   
    
    this.totaltransferencia = 0;

    this.total = "";

    function f2(obj){

      return new Promise((resolve,reject) => {

        if(localStorage.getItem('usuarios')!= null) usuarios = JSON.parse(localStorage.getItem('usuarios'));

        if(localStorage.getItem('ultimas_transferencias')!= null) ultimas = JSON.parse(localStorage.getItem('ultimas_transferencias'));

        if(localStorage.getItem('cartoes')!= null) cartoes = JSON.parse(localStorage.getItem('cartoes'));

        resolve(true);

      })

    }

    async function f1(obj){

      try {

          var x = await f2(obj).then(

            function() {              

              setTimeout(() => {

                //apenas transferencias concluidas
                let lista = ultimas.filter(element => {return element.situacao == 1});    

                obj.tam = lista.length;

                lista.forEach(element => {

                  idcartao = element.idcartao;
                  idusuario = element.idusuario;
            
                  cartao = cartoes.find(card =>{return card.id == idcartao})
            
                  usuario = usuarios.find(user =>{return user.id == idusuario})      
            
                  aux = parseFloat(element.valor.replace('R$','').replace('.','').replace('.','').replace('.','').replace('.','').replace(',','.'))
                  
                  numero = 0;
                  nome ="";
                  img = "";
                  username="";
            
                  if(cartao!=undefined) numero = cartao.numero;
                  if(usuario!=undefined){
                    nome = usuario.name;
                    img = usuario.img;     
                    username = usuario.username;
                  }      
                  
                  obj.ultimastransferencias.push({username:username,usuario:nome,cartao:numero,valor2:aux,valor:aux.toLocaleString("pt-BR", { style: "currency", currency: 'BRL' }), data: element.data,img:img});      
            
                  obj.totaltransferencia += aux;
            
                });
            
                obj.total = obj.totaltransferencia.toLocaleString("pt-BR", { style: "currency", currency: 'BRL' });    
            
                obj.ultimastransferencias.sort(function(a, b){
            
                  let dataaux = a.data.split(' ')
                  let aux = dataaux[0].split('/')
                  let aux2 = dataaux[1].split(':')
            
                  let k = new Date(aux[2],aux[1]-1,aux[0],aux2[0],aux2[1],aux2[2])
                  
                  dataaux=[]
                  aux=[]
                  aux2=[]
            
                  dataaux = b.data.split(' ')
                  aux = dataaux[0].split('/')
                  aux2 = dataaux[1].split(':')
            
                  let y = new Date(aux[2],aux[1]-1,aux[0],aux2[0],aux2[1],aux2[2]);      
                  
                  if (k > y) {return -1;}
            
                  if (k < y) {return 1;}
            
                  return 0;
            
                });

                obj.ultimastransferencias_filtrados = obj.ultimastransferencias.slice(0,obj.limite);               

                loader.dismiss();

              },500);

            }

          );

      } catch(e) {

        let toast = obj.toastCtrl.create({message: 'Não foi possível carregar as últimas transferências. Tente novamente.',duration:2000});
      
        toast.present();

        loader.dismiss();
      
        console.warn(e);
  
      }

    }

    let loader = this.loadingCtrl.create({spinner:'bubbles'});    
  
    loader.present();

    f1(this);

  }
  
  doInfinite(infiniteScroll) {

    let inicio = this.limite;

    this.limite += 10;

    let tam = this.ultimastransferencias.length;

    if(this.limite>tam) this.limite = tam;
    
    for (let i = inicio; i < this.limite; i++) {
      
      this.ultimastransferencias_filtrados.push(this.ultimastransferencias[i]);
    }

    setTimeout(() => {        

        infiniteScroll.complete();

    }, 500);

  }

}
