import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ValorTransferenciaPage } from './valor-transferencia';

@NgModule({
  declarations: [
    ValorTransferenciaPage,
  ],
  imports: [
    IonicPageModule.forChild(ValorTransferenciaPage),
  ],
})
export class ValorTransferenciaPageModule {}
