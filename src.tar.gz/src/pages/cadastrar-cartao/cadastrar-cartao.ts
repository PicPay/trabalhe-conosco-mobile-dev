import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,LoadingController,ToastController,ActionSheetController } from 'ionic-angular';

/**
 * Generated class for the CadastrarCartaoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cadastrar-cartao',
  templateUrl: 'cadastrar-cartao.html',
})
export class CadastrarCartaoPage {

  numero : string = "";
  cvv : string = "";
  validade1 : string = "";
  validade2 : string = "";
  flag : boolean = true;
  flagsalvo : boolean = false;

  constructor(public navCtrl: NavController, public navParams: NavParams,public loadingCtrl: LoadingController,public toastCtrl: ToastController,public actionSheetCtrl: ActionSheetController) {}

  ionViewDidLoad() {
    
  } 

  salvar(){

    let cartoes : any = [];        

    let num = this.numero;

    if(this.validarNumero()) return

    if(this.validade2.length == 0){

      let toast = this.toastCtrl.create({message: 'Informe a data de validade do cartão de crédito.',duration:2000});

      toast.present();

      return

    }

    if(this.validarCvv()) return    

    if(localStorage.getItem('cartoes')!=null) cartoes = JSON.parse(localStorage.getItem('cartoes'));

    let cartao = cartoes.find(function(value){return value.numero == num})
    
    if(cartao != undefined){

      let toast1 = this.toastCtrl.create({message: 'Esse cartão já foi cadastrado.',duration:2000});

      toast1.present();

      return;
      
    }

    const loader = this.loadingCtrl.create({content: "",spinner:'bubbles'});

    loader.present();        

    let tam = cartoes.length+1;    

    cartoes.push({id:tam,numero:num,validade:this.validade2,cvv:this.cvv});

    localStorage.setItem('cartoes',JSON.stringify(cartoes));

    loader.dismiss();

    let toast2 = this.toastCtrl.create({message: 'Cartão cadastrado com sucesso.',duration:2000});

    toast2.present();    

    this.navCtrl.pop();

  }

  validarCvv(){

    let regexp1 = new RegExp(/^\d+$/i);    

    if(this.cvv.length == 0){

        let toast = this.toastCtrl.create({message: 'Informe o CVV do cartão.',duration:2000});

        toast.present();       

        return true

    }  
    
    if (regexp1.test(this.cvv)) {

    }else{

        let toast = this.toastCtrl.create({message: 'Informe o CVV do cartão corretamente.',duration:2000});

        toast.present();        

        return true

    }

    return false;
  }   

  cancelar(){

    if(this.numero.length > 0 || this.validade2.length > 0 || this.cvv.length > 0){    

      let actionSheet = this.actionSheetCtrl.create({
        title: 'Deseja cancelar o cadastro do cartão ?',
        buttons: [
          {
            text: 'Sim',            
            handler: () => {
              this.navCtrl.pop();
            }
          },
          {
            text: 'Não',
            handler: () => {}
          }
        ]
      });
   
      actionSheet.present();

    }else{

      this.navCtrl.pop();

    }

  }

  validarNumero(){

    let regexp1 = new RegExp(/^\d+$/i);    

    if(this.numero.length == 0){

        let toast = this.toastCtrl.create({message: 'Informe o numero do cartão.',duration:2000});

        toast.present();       

        return true

    }  
    
    if (regexp1.test(this.numero)) {

    }else{

        let toast = this.toastCtrl.create({message: 'Informe o número do cartão corretamente.',duration:2000});

        toast.present();        

        return true

    }

    return false;
  } 
  
  public customOptionsValidade: any = {

    buttons: [

      {text: 'Limpar',handler: (data) => {
        this.validade1 = '';
        this.validade2 = '';
      }},

      {

        text: 'Ok',

        handler: (data) => {         

          let dataagora = new Date();

          let event1 = new Date(data.year.value, data.month.value-1,1,0,0,0);          

          let options1 = { year: 'numeric', month: 'numeric', day: 'numeric'};

          let date = event1.toLocaleDateString('pt-BR', options1);                                                 

          dataagora.setHours(0)
          dataagora.setMinutes(0)
          dataagora.setSeconds(0)                    

          if(event1 > dataagora){

            let options2 = { year: 'numeric', month: 'numeric'};

            date = event1.toLocaleDateString('pt-BR', options2);            

            this.validade1 = event1.toISOString();

            this.validade2 = date;

          }else{

            let toast = this.toastCtrl.create({message: 'Esse cartão está vencido. Informe uma data válida.',duration:2000});

            toast.present();

          }

        }

      },

      {

        text: 'Cancelar',

        handler: (data) => {}

      }

    ]

  } 

}
