import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { CadastrarCartaoPage } from '../cadastrar-cartao/cadastrar-cartao';
import { EditarCartaoPage } from '../editar-cartao/editar-cartao';


@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {

  cartoes : any = [];    

  constructor(public navCtrl: NavController) {

  }

  ionViewWillEnter() {      

    if(localStorage.getItem('cartoes')!= null) this.cartoes = JSON.parse(localStorage.getItem('cartoes'))    

    if(this.cartoes.length>0){

      this.cartoes.sort(function(a, b){

        let dataaux = a.validade.split('/')     
        
        let k = new Date(dataaux[2],dataaux[1]-1,dataaux[0])
        
        dataaux=[]      

        dataaux = b.validade.split('/')      
        
        let y = new Date(dataaux[2],dataaux[1]-1,dataaux[0])
        
        if (k > y) {return -1;}

        if (k < y) {return 1;}

        return 0;

      })        

    }    

  }

  novo(){

    this.navCtrl.push(CadastrarCartaoPage)

  }

  editar(id,numero,validade,cvv){

    this.navCtrl.push(EditarCartaoPage,{idcartao:id, numero:numero,validade:validade,cvv:cvv})

  }

}
