import { Component } from '@angular/core';

import { NavController,ToastController,LoadingController } from 'ionic-angular';

import { ValorTransferenciaPage } from '../valor-transferencia/valor-transferencia';

import { HttpProvider } from '../../providers/http/http';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  providers: [HttpProvider]  
})

export class HomePage {

  public service : HttpProvider;

  usuarios : any = [];
  usuarios_filtrados : any = [];
  reg_usuarios : any = [];
  limite : number = 10;

  constructor(public loadingCtrl: LoadingController,public navCtrl: NavController,public HttpProvider:HttpProvider,public toastCtrl: ToastController){

    this.service = HttpProvider;
    
  }

  ionViewDidLoad(){    

    this.listarUsuarios();

  }

  listarUsuarios(){

    function f2(obj){

      return new Promise((resolve,reject) => { 

        //listar usuarios para transferencia
        obj.service.listUsers().subscribe(

          data =>{        
            
            obj.usuarios = data;
            obj.reg_usuarios = data;
            
          },

          err =>{

            let toast = obj.toastCtrl.create({message: 'Não foi possível carregar a lista de usuários. Tente novamente.',duration:2000});
      
            toast.present();        

            reject(true);

          },

          () =>{        

            obj.usuarios.sort(function(a, b){
              if (a.name > b.name) {return 1;}
              if (a.name < b.name) {return -1;}
              return 0;
            });

            localStorage.setItem('usuarios',JSON.stringify(obj.usuarios));            
            
            resolve(true);

          }

        );

      });
    
    }

    async function f1(obj){

      try {

          var x = await f2(obj).then(

            function() {              

              setTimeout(() => {                           
                
                obj.usuarios_filtrados = obj.usuarios.slice(0,obj.limite);

                loader.dismiss();

              },500);

          });

      } catch(e) {
        
        console.warn(e);

        let toast = obj.toastCtrl.create({message: 'Não foi possível carregar a lista de usuários. Tente novamente.',duration:2000});
      
        toast.present();

        loader.dismiss();
  
      }

    }

    let loader = this.loadingCtrl.create({spinner:'bubbles'});    
  
    loader.present();

    f1(this);

  }

  doRefresh(refresher) {

    this.usuarios = [];
    this.usuarios_filtrados = [];

    this.listarUsuarios();
    
    refresher.complete();
    
  }

  trasferir(idusuario,nomeususario,img,username){
    this.navCtrl.push(ValorTransferenciaPage,{id : idusuario, nome: nomeususario, imagem: img, user:username});
  }

  getItems(ev: any) {   

    // set val to the value of the searchbar
    const val = ev.target.value;

    if(val.length>0){

      // if the value is an empty string don't filter the items
      if (val && val.trim() != '') {
        this.usuarios_filtrados = this.usuarios.filter((item) => {
          return ((item.name.toLowerCase().indexOf(val.toLowerCase()) > -1) || (item.username.toLowerCase().indexOf(val.toLowerCase()) > -1));
        })
      }

    }else{     
      
      this.usuarios_filtrados = this.usuarios.slice(0,this.limite);

    }

  }  

  doInfinite(infiniteScroll) {

    let inicio = this.limite;

    this.limite += 10;

    let tam = this.usuarios.length;

    if(this.limite>tam) this.limite = tam;
    
    for (let i = inicio; i < this.limite; i++) {
      
      this.usuarios_filtrados.push(this.usuarios[i]);
    }

    setTimeout(() => {        

        infiniteScroll.complete();

    }, 500);

  }

}
